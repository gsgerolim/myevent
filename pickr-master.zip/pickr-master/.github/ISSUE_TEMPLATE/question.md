---
name: Question
about: General request of information / help
title: ''
labels: question
assignees: ''

---

#### Your question

<!-- Please check if the question hasn't already been asked yet and check the FAQ's -->
#### Your environment:
```
Version (see Pickr.version):
Used bundle (es5 or normal one):
Used theme (default is classic): 
Browser-version:  
Operating-system:  
```
